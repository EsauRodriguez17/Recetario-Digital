#include "exception.hpp"

Exception::Exception() {}
