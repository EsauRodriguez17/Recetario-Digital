#ifndef LISTAINGREDIENTES_H
#define LISTAINGREDIENTES_H

#include "ingrediente.hpp"
#include "exception.hpp"

class ListaIngredientes{
private:
    Ingrediente **ingredientes;
    int ultimaPosicion;
    int capacidad;

    void copiarTodo(const ListaIngredientes&);
    void aumentarCapacidad();

public:
    ListaIngredientes();
    ListaIngredientes(const ListaIngredientes&);
    ~ListaIngredientes();

    ListaIngredientes& operator=(const ListaIngredientes&);

    bool vacia();
    bool llena();
    bool posicionValida(const int&);

    void insertarIngrediente(Ingrediente*);
    void eliminarIngrediente(int&);

    int getPrimeraPosicion();
    int getUltimaPosicion();
    int getPosicionPrevia(const int&);
    int getSiguientePosicion(const int&);

    Ingrediente* recuperarIngrediente(const int&);

    int busquedaLineal(const Ingrediente*,int (*cmp)(const Ingrediente&, const Ingrediente&)) const;
    int busquedaBinaria(const Ingrediente*,int (*cmp)(const Ingrediente&, const Ingrediente&)) const;
    int buscarPosicionOrdenada(const Ingrediente*) const;

    QString toQstring() ;
    void anular();

    int size() const;
};

#endif // LISTAINGREDIENTES_H
