#include "mainwindow.hpp"
#include "ui_mainwindow.h"

using namespace std;

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow){
    ui->setupUi(this);
    this->setWindowTitle("Recetario Digital");
    setFixedSize(1080, 760);
    ui->homeButton->setChecked(true);
    this->lastId=0;
    ui->messageWidget->setVisible(false);
    cargarRecetas();

    initializeImagesDirectory();
    setupIngredientsSection();
    setupRecipesCardsSection();
    setCursorPointerForAllButtons();
    setupValidators();
    setupConnections();

    if(listaRecetas.size()>=0){
        for(int i=0;i<listaRecetas.size();i++){
            addRecipeCardWidget(listaRecetas.recuperarReceta(i));
        }
    }

    ui->pages->setCurrentIndex(homePage);
}

MainWindow::~MainWindow(){
    delete ui;
}

void MainWindow::initializeImagesDirectory() {
    QString imagesDir = QDir::currentPath() + "/imagenes";
    QDir dir(imagesDir);
    if (!dir.exists()) {
        dir.mkpath(".");
        qDebug() << "Carpeta de imágenes creada en:" << imagesDir;
    } else {
        qDebug() << "La carpeta de imágenes ya existe en:" << imagesDir;
    }
}

void MainWindow::setupRecipesCardsSection() {
    QWidget *recipesCardsContainer = new QWidget();
    recipesCardsLayout = new QGridLayout(recipesCardsContainer);
    ui->recipesArea->setWidget(recipesCardsContainer);
    ui->recipesArea->setWidgetResizable(true);
}

void MainWindow::setupIngredientsSection() {
    QWidget *ingredientsContainer = new QWidget();
    ingredientsLayout = new QVBoxLayout(ingredientsContainer);
    ingredientsContainer->setLayout(ingredientsLayout);
    ui->ingredientsArea->setWidget(ingredientsContainer);
    ui->ingredientsArea->setWidgetResizable(true);

    connect(ui->addIngredientButton, &QPushButton::clicked, this, [this]() {
        addIngredientWidget();
    });
}

void MainWindow::setupValidators() {
    QIntValidator *validator = new QIntValidator(1, std::numeric_limits<int>::max(), this);
    ui->lineEditDuration->setValidator(validator);

}

void MainWindow::setupConnections(){

    connect(ui->homeButton,&QPushButton::clicked, this, &MainWindow::onHomeButtonClicked);
    connect(ui->recipesButton,&QPushButton::clicked, this, &MainWindow::onRecipesButtonClicked);

    connect(ui->addRecipeButton,&QPushButton::clicked, this, &MainWindow::onAddRecipeButtonClicked);
    connect(ui->deleteAllRecipesButton,&QPushButton::clicked, this, &MainWindow::onDeleteAllRecipesButtonClicked);

    connect(ui->cancelButton,&QPushButton::clicked, this, &MainWindow::onCancelButtonClicked);
    connect(ui->confirmButton,&QPushButton::clicked, this, &MainWindow::onConfirmButtonClicked);

    connect(ui->uploadPhotoButton,&QPushButton::clicked, this, &MainWindow::onUploadPhotoButtonClicked);
    connect(ui->deleteAllIngredientsButton,&QPushButton::clicked, this, &MainWindow::onDeleteAllIngredientsButtonClicked);

    ui->comboBoxSort->addItem("--Selecciona--");
    ui->comboBoxSort->setItemData(0, true, Qt::UserRole-1);

    // Agregar las opciones de ordenamiento
    ui->comboBoxSort->addItem("Nombre");
    ui->comboBoxSort->addItem("Tiempo de Preparacion");
    connect(ui->comboBoxSort, &QComboBox::currentIndexChanged, this, &MainWindow::onSortChanged);
    ui->comboBoxSort->setCurrentIndex(0);

    //Agregar las opciones de filtrado
    ui->comboBoxFilter->addItem("Todas");
    ui->comboBoxFilter->addItem("Desayuno");
    ui->comboBoxFilter->addItem("Comida");
    ui->comboBoxFilter->addItem("Cena");
    ui->comboBoxFilter->addItem("Navideño");
    connect(ui->comboBoxFilter,&QComboBox::currentIndexChanged,this,&MainWindow::onFilterChanged);
    ui->comboBoxFilter->setCurrentIndex(0);

    connect(ui->searchRecipeLineEdit, &QLineEdit::returnPressed, this, &MainWindow::onSearchButtonClicked);

    connect(ui->searchRecipeButton, &QPushButton::clicked, this, &MainWindow::onSearchButtonClicked);

    connect(ui->searchRecipeLineEdit, &QLineEdit::textChanged, this, &MainWindow::onTextChanged);
    connect(ui->clearSearchLineEditButton, &QPushButton::clicked, this, &MainWindow::onClearButtonClicked);

    ui->clearSearchLineEditButton->setVisible(false);

    connect(ui->exploreRecipesButton,&QPushButton::clicked, this, &MainWindow::onRecipesButtonClicked);
    connect(ui->returnButton,&QPushButton::clicked, this, &MainWindow::onReturnButtonClicked);

}

void MainWindow::agregarReceta(){
    Receta *nuevaReceta=new Receta;

    if(nuevaReceta==nullptr){
        QMessageBox::critical(this,"Error","Error de memoria: no se pudo reservar memoria para la receta.",QMessageBox::Ok);
    }

    nuevaReceta->setNombre(ui->lineEditName->text());
    nuevaReceta->setCategoria(static_cast<Receta::Categoria>(ui->comboBoxCategory->currentIndex()));
    nuevaReceta->setTiempoPreparacion(ui->lineEditDuration->text().toInt());
    Nombre autorReceta(ui->lineEditAutorFirstName->text(),ui->lineEditAutorLastName->text());
    nuevaReceta->setAutor(autorReceta);
    QString sourcePath = ui->uploadPhotoButton->property("imagePath").toString();
    QString imagesDir = QDir::currentPath() + "/imagenes";
    QString destinationPath = imagesDir + "/" + QFileInfo(sourcePath).fileName(); // Nueva ruta

    // Copiar la imagen a la carpeta de imágenes
    if (QFile::copy(sourcePath, destinationPath)) {
        nuevaReceta->setRutaImagen(destinationPath);
        qDebug() << "Imagen copiada a:" << destinationPath;
    } else {
        qDebug() << "Error al copiar la imagen.";
    }
    nuevaReceta->setPreparacion(ui->instructionsText->toPlainText());

    agregarIngredientesReceta(nuevaReceta);

    try {
        listaRecetas.agregarReceta(nuevaReceta);
    } catch (const std::exception& e) {
        QMessageBox::warning(this, "Error", e.what());
    }

    addRecipeCardWidget(nuevaReceta);

    qDebug()<<listaRecetas.getUltimaPosicion();
    qDebug()<<listaRecetas.size();
    qDebug()<< "El tamaño del puntero a receta es: " << sizeof(nuevaReceta) << " bytes.";
    qDebug()<< "El tamaño del objeto receta al que apunta es: " << sizeof(*nuevaReceta) << " bytes.";

}


void MainWindow::modificarReceta(){
    RecipeCard *recipeCard=ui->confirmButton->property("recipePointer").value<RecipeCard*>();
    Receta *receta=recipeCard->getRecetaAsociada();

    if (receta->getNombre() != ui->lineEditName->text()) {
        receta->setNombre(ui->lineEditName->text());
    }

    int nuevaCategoria = ui->comboBoxCategory->currentIndex();
    if (receta->getCategoriaToInt() != nuevaCategoria) {
        receta->setCategoria(static_cast<Receta::Categoria>(nuevaCategoria));
    }

    int nuevoTiempoPreparacion = ui->lineEditDuration->text().toInt();
    if (receta->getTiempoPreparacion() != nuevoTiempoPreparacion) {
        receta->setTiempoPreparacion(nuevoTiempoPreparacion);
    }

    Nombre nuevoAutor(ui->lineEditAutorFirstName->text(), ui->lineEditAutorLastName->text());
    if (receta->getAutor() != nuevoAutor) {
        receta->setAutor(nuevoAutor);
    }

    // Verificar si se ha cambiado la imagen
    QString sourcePath = ui->uploadPhotoButton->property("imagePath").toString();
    QString currentImagePath = receta->getRutaImagen();

    if (sourcePath != currentImagePath) {
        QString imagesDir = QDir::currentPath() + "/imagenes";
        QString destinationPath = imagesDir + "/" + QFileInfo(sourcePath).fileName();

        // Eliminar la imagen antigua si existe
        if (!currentImagePath.isEmpty() && QFile::exists(currentImagePath)) {
            QFile::remove(currentImagePath); // Eliminar archivo
            qDebug() << "Imagen antigua eliminada:" << currentImagePath;
        }

        if (QFile::copy(sourcePath, destinationPath)) {
            receta->setRutaImagen(destinationPath);
            qDebug() << "Imagen copiada a:" << destinationPath;
        } else {
            qDebug() << "Error al copiar la nueva imagen.";
        }
    }

    if (receta->getPreparacion() != ui->instructionsText->toPlainText()) {
        receta->setPreparacion(ui->instructionsText->toPlainText());
    }

    receta->eliminarTodosLosIngredientes();
    agregarIngredientesReceta(receta);

    recipeCard->actualizarVista();

}


void MainWindow::agregarIngredientesReceta(Receta *receta){
    for(int i=0;i< ingredientsLayout->count();i++){
        QWidget *widget= ingredientsLayout->itemAt(i)->widget();

        IngredientWidget *ingredientWidget=qobject_cast<IngredientWidget*>(widget);
        if(ingredientWidget){
            QString nombre=ingredientWidget->getNombre();
            float cantidad=ingredientWidget->getCantidad();
            Ingrediente::UnidadMedida unidad=ingredientWidget->getUnidadMedida();

            Ingrediente *nuevoIngrediente=new Ingrediente(nombre,cantidad,unidad);
            receta->agregarIngrediente(nuevoIngrediente);

            qDebug()<< "El tamaño del puntero a Ingrediente es: " << sizeof(nuevoIngrediente) << " bytes.";
            qDebug()<< "El tamaño del objeto Ingrediente  al que apunta es: " << sizeof(*nuevoIngrediente) << " bytes.";
        }

    }
}

void MainWindow::clearRecipeCards(){
    while (QLayoutItem* item = recipesCardsLayout->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            widget->deleteLater();
        }
        delete item;
    }
}

void MainWindow::addRecipeCardWidget(Receta *receta){
        // Crear una nueva RecipeCard con la receta
        RecipeCard *recetaCard = new RecipeCard(receta);

        recipesCardsLayout->addWidget(recetaCard, row, col);
        col++;
        if (col >= maxColumns) {
            col = 0;
            row++;
        }

        connect(recetaCard, &RecipeCard::modifyClicked, this, [this, recetaCard]() {
            onModifyRecipeClicked(recetaCard);
        });
        connect(recetaCard, &RecipeCard::deleteClicked, this, [this, recetaCard]() {
            onDeleteRecipeClicked(recetaCard);
        });
        connect(recetaCard, &RecipeCard::imageClicked, this, [this, recetaCard]() {
            onViewRecipe(recetaCard);
        });

        qDebug()<< "El tamaño del puntero a recetaCard es: " << sizeof(recetaCard) << " bytes.";
        qDebug()<< "El tamaño del objeto recetaCard al que apunta es: " << sizeof(*recetaCard) << " bytes.";

}


void MainWindow::addIngredientWidget(){
    IngredientWidget *newIngredientWidget=new IngredientWidget;
    connect(newIngredientWidget, &IngredientWidget::deleteClicked, this, [newIngredientWidget, this]() {
        ingredientsLayout->removeWidget(newIngredientWidget);  // Elimina el widget del layout
        newIngredientWidget->deleteLater();  // Destruye el widget
    });
    ingredientsLayout->addWidget(newIngredientWidget);
    qDebug()<< "El tamaño del puntero a IngredientWidget vacio es: " << sizeof(newIngredientWidget) << " bytes.";
    qDebug()<< "El tamaño del objeto IngredientWidget vacio al que apunta es: " << sizeof(*newIngredientWidget) << " bytes.";
}

void MainWindow::clearIngredientWidgets(){
    while (QLayoutItem* item = ingredientsLayout->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            widget->deleteLater();
        }
        delete item;
    }
}

void MainWindow::actualizarRecipeCardWidgets(){
    for(int i=0;i< recipesCardsLayout->count();i++){
        QWidget *widget= recipesCardsLayout->itemAt(i)->widget();

        RecipeCard *recipeCardWidget=qobject_cast<RecipeCard*>(widget);
        if(recipeCardWidget){
            recipeCardWidget->setRecetaAsociada(listaRecetas.recuperarReceta(i));
            recipeCardWidget->actualizarVista();
        }

    }
}


void MainWindow::desactivarBotonesNavBar(){
    ui->homeButton->setEnabled(false);
    ui->recipesButton->setEnabled(false);
}


void MainWindow::activarBotonesNavBar(){
    ui->homeButton->setEnabled(true);
    ui->recipesButton->setEnabled(true);
}

void MainWindow::setCursorPointerForAllButtons(){
    QList<QWidget *> widgets = this->findChildren<QWidget *>();
    for (QWidget *widget : widgets) {
        // Verifica si el widget es un QPushButton
        QPushButton *button = qobject_cast<QPushButton *>(widget);
        if (button) {
            button->setCursor(Qt::PointingHandCursor); // Cambia el cursor a "pointer hand"
        }
    }
}

bool MainWindow::validarCamposAddRecipePage(){
    QList<QLineEdit*> camposTexto{
        ui->lineEditName,
        ui->lineEditDuration,
        ui->lineEditAutorFirstName,
        ui->lineEditAutorLastName
    };

    QStringList camposFaltantes;
    bool camposVacios=false;

    for (auto campo : camposTexto) {
        if (campo->text().isEmpty()) {
            camposVacios=true;
            break;
        }
    }

    if(camposVacios){
        camposFaltantes << "Hay campos de texto vacios en la informacion general";
    }

    if(ui->uploadPhotoImage->pixmap().isNull()){
        camposFaltantes << "Debes agregar una imagen del platillo";
    }

    if (ui->instructionsText->toPlainText().isEmpty()) {
        camposFaltantes << "Debes agregar el procedimiento";
    }

    bool ingredientesValidos=true;
    for(int i=0;i<ingredientsLayout->count();i++){
        QWidget *widget =ingredientsLayout->itemAt(i)->widget();

        if(IngredientWidget *ingredientWidget=qobject_cast<IngredientWidget *>(widget)){
            if(ingredientWidget->getNombre().isEmpty() || ingredientWidget->getCantidad() <0.001 ){
                ingredientesValidos=false;
                break;
            }
        }
    }

    if(!ingredientesValidos){
        camposFaltantes << "Debes llenar todos los campos de los ingredientes";
    }

    if (!camposFaltantes.isEmpty()) {
        QString mensaje =camposFaltantes.join("\n");
        QMessageBox::warning(this, "Campos Vacíos", mensaje);
        return false;
    }

    return true;

}

void MainWindow::limpiarCamposAddRecipePage(){
    ui->lineEditName->clear();
    ui->lineEditDuration->clear();
    ui->comboBoxCategory->setCurrentIndex(0);
    ui->lineEditAutorFirstName->clear();
    ui->lineEditAutorLastName->clear();
    ui->instructionsText->clear();
    ui->uploadPhotoImage->clear();
    clearIngredientWidgets();
    ui->confirmButton->setProperty("recipePointer", QVariant());
    ui->uploadPhotoButton->setProperty("imagePath", QVariant());
}


void MainWindow::llenarCamposAddRecipePage(Receta& recipe){
    ui->lineEditName->setText(recipe.getNombre());
    ui->lineEditDuration->setText(QString::number(recipe.getTiempoPreparacion()));
    ui->comboBoxCategory->setCurrentIndex(recipe.getCategoriaToInt());
    ui->lineEditAutorFirstName->setText(recipe.getAutor().getNombre());
    ui->lineEditAutorLastName->setText(recipe.getAutor().getApellido());

    QString fileName=recipe.getRutaImagen();
    ui->uploadPhotoButton->setProperty("imagePath",fileName);

    if(!fileName.isEmpty()){
        QPixmap image(fileName);
        ui->uploadPhotoImage->setPixmap(image);
        ui->uploadPhotoImage->setScaledContents(true);
    }

    ui->instructionsText->setText(recipe.getPreparacion());

    ListaIngredientes& lista=recipe.getListaIngredientes();

    int i=0;
    if(!lista.vacia()){
        while(i<=lista.getUltimaPosicion()){
            Ingrediente *in=lista.recuperarIngrediente(i);
            IngredientWidget *newIngredientWidget=new IngredientWidget(*in);
            connect(newIngredientWidget, &IngredientWidget::deleteClicked, this, [newIngredientWidget, this]() {
                ingredientsLayout->removeWidget(newIngredientWidget);  // Elimina el widget del layout
                newIngredientWidget->deleteLater();  // Destruye el widget
            });
            ingredientsLayout->addWidget(newIngredientWidget);
            i++;
        }

    }
}

void MainWindow::llenarCamposViewRecipePage(Receta * receta){
    ui->tittleViewRecipe->setText(receta->getNombre());
    ui->imageViewRecipe->setPixmap(QPixmap(receta->getRutaImagen()));
    ui->Procedimiento->setText(receta->getPreparacion());
    ui->Ingredientes->setText(receta->getListaIngredientes().toQstring());
    ui->tiempoPreparacion->setText(QString::number(receta->getTiempoPreparacion())+" Minutos");
    ui->autor->setText(receta->getAutor().toQstring());
    ui->categoria->setText(receta->getCategoriaToQstring());
}

void MainWindow::onModifyRecipeClicked(RecipeCard *recipeCard) {
    Receta *recipe= recipeCard->getRecetaAsociada();

    ui->recipesButton->setChecked(false);
    ui->pages->setCurrentIndex(addRecipePage);
    ui->confirmButton->setText("Guardar Cambios");
    ui->confirmButton->setProperty("recipePointer", QVariant::fromValue(recipeCard));

    ui->uploadPhotoButton->setText("Cambiar Imagen");
    ui->uploadPhotoButton->setStyleSheet("color: black; border-bottom: 2px solid blue;");

    desactivarBotonesNavBar();
    llenarCamposAddRecipePage(*recipe);
}


void MainWindow::onDeleteRecipeClicked(RecipeCard *recipeCard) {
    Receta* recipe=recipeCard->getRecetaAsociada();
    int pos=listaRecetas.localiza(recipe);

    if(pos !=-1){
        try {
            listaRecetas.eliminarReceta(pos);
            recipesCardsLayout->removeWidget(recipeCard);
            recipeCard->deleteLater();
            qDebug()<<"Eliminada Correctamente";
            qDebug()<<listaRecetas.getUltimaPosicion();
            qDebug()<<listaRecetas.size();
        } catch (const std::exception& e) {
            QMessageBox::warning(this, "Error", e.what());
        }
    }
    else{
        qDebug()<<"No se pudo localizar la receta";
    }

}

void MainWindow::onViewRecipe(RecipeCard *recipeCard){
    Receta* recipe=recipeCard->getRecetaAsociada();
    ui->pages->setCurrentIndex(viewRecipePage);
    llenarCamposViewRecipePage(recipe);
}

void MainWindow::onSortChanged(int index){
    if(listaRecetas.vacia()){return;}

    if(index==1){
        listaRecetas.quickSort(Receta::compararPorNombre);
    }
    else{
        listaRecetas.quickSort(Receta::compararPorTiempoPreparacion);
    }

    actualizarRecipeCardWidgets();
}

void MainWindow::onFilterChanged(int){

    if(recipesCardsLayout->count()>0){
        QString categoriaSeleccionada = ui->comboBoxFilter->currentText();
        filtrarPorCategoria(categoriaSeleccionada);
        recipesCardsLayout->update();
    }

}

void MainWindow::onSearchButtonClicked(){
    qDebug()<<"Busqueda realizada";

    QString search=ui->searchRecipeLineEdit->text().trimmed();
    if(!search.isEmpty()){
        Receta * objetivo=new Receta;
        objetivo->setNombre(search);

        int pos=listaRecetas.busquedaBinaria(objetivo,Receta::compararPorNombre);
        if(pos!= -1){
            Receta *receta=listaRecetas.recuperarReceta(pos);
            llenarCamposViewRecipePage(receta);
            ui->pages->setCurrentIndex(viewRecipePage);
        }
        else{
            ui->messageWidget->setVisible(true);

            QTimer::singleShot(2000, this, [this]() {
                ui->messageWidget->setVisible(false);
            });
        }
        delete objetivo;
    }


}

void MainWindow::onTextChanged(const QString &text){
    ui->clearSearchLineEditButton->setVisible(!text.isEmpty());
}

void MainWindow::onClearButtonClicked(){
    ui->searchRecipeLineEdit->clear();
    ui->clearSearchLineEditButton->setVisible(false);
}
void MainWindow::filtrarPorCategoria(QString categoriaSeleccionada){
    for (int i = 0; i < recipesCardsLayout->count(); i++) {
        QWidget* widget = recipesCardsLayout->itemAt(i)->widget();
        RecipeCard* recipeCardWidget = qobject_cast<RecipeCard*>(widget);

        if (recipeCardWidget) {
            // Recupera la receta asociada a la RecipeCard
            Receta* receta = recipeCardWidget->getRecetaAsociada();

            // Verifica si la receta tiene la categoría seleccionada
            if (receta->getCategoriaToQstring() == categoriaSeleccionada || categoriaSeleccionada == "Todas") {
                recipeCardWidget->setVisible(true);  // Mostrar si coincide
            } else {
                recipeCardWidget->setVisible(false); // Ocultar si no coincide
            }
        }
    }
}

void MainWindow::onHomeButtonClicked(){
    ui->pages->setCurrentIndex(homePage);
    ui->recipesButton->setChecked(false);
    ui->homeButton->setChecked(true);
}

void MainWindow::onRecipesButtonClicked(){
    ui->pages->setCurrentIndex(recipesPage);
    ui->homeButton->setChecked(false);
    ui->recipesButton->setChecked(true);
}

void MainWindow::onAddRecipeButtonClicked(){
    ui->recipesButton->setChecked(false);
    desactivarBotonesNavBar();
    ui->pages->setCurrentIndex(addRecipePage);
    ui->confirmButton->setText("Agregar Receta");

}

void MainWindow::onDeleteAllRecipesButtonClicked(){
    if(recipesCardsLayout->count() == 0){
        return;
    }

    QMessageBox::StandardButton reply;

    reply = QMessageBox::question(this, "Eliminar todas las recetas",
                                  "¿Estás seguro de que deseas eliminar todas las recetas?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        listaRecetas.anular();
        clearRecipeCards();
    }
}

void MainWindow::onCancelButtonClicked(){
    activarBotonesNavBar();
    limpiarCamposAddRecipePage();
    ui->pages->setCurrentIndex(recipesPage);
    ui->recipesButton->setChecked(true);
    ui->uploadPhotoButton->setStyleSheet("color: rgb(240, 128, 0); border-bottom: 2px solid rgb(240, 128, 0);");
}

void MainWindow::onConfirmButtonClicked(){
    if(!validarCamposAddRecipePage()){
        return;
    }

    if(ui->confirmButton->text()=="Agregar Receta"){
        agregarReceta();
    }
    else{
        modificarReceta();
        ui->uploadPhotoButton->setStyleSheet("color: rgb(240, 128, 0); border-bottom: 2px solid rgb(240, 128, 0);");
    }

    limpiarCamposAddRecipePage();
    activarBotonesNavBar();
    ui->pages->setCurrentIndex(recipesPage);
    ui->recipesButton->setChecked(true);
}


void MainWindow::onUploadPhotoButtonClicked(){
    QString fileName = QFileDialog::getOpenFileName(this, tr("Seleccionar Imagen"),
                                                    "", tr("Imágenes (*.png *.jpg *.jpeg *.bmp *.gif);;Todos los archivos (*)"));

    if (!fileName.isEmpty()) {
        QPixmap image(fileName);
        ui->uploadPhotoImage->setPixmap(image);
        ui->uploadPhotoImage->setScaledContents(true);
        if (image.isNull()) {
            QMessageBox::warning(this, tr("Error"), tr("No se pudo cargar la imagen."));
            return;
        }
    }

    ui->uploadPhotoButton->setProperty("imagePath", fileName);

}

void MainWindow::onDeleteAllIngredientsButtonClicked(){
    if(ingredientsLayout->count() == 0){
        return;
    }

    QMessageBox::StandardButton reply;

    reply = QMessageBox::question(this, "Eliminar todos los ingredientes",
                                  "¿Estás seguro de que deseas eliminar todos las ingredientes?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        clearIngredientWidgets();
    }
}

void MainWindow::onReturnButtonClicked(){
    ui->pages->setCurrentIndex(recipesPage);
}

void MainWindow::guardarRecetas() {
    QString datosRecetas = QDir::currentPath() + "/recetas.json";
    QFile file(datosRecetas);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo para guardar las recetas.");
        return;
    }

    QJsonArray recetasArray;

    int cantidadRecetas = listaRecetas.size();
    for (int i = 0; i < cantidadRecetas; i++) {
        Receta *receta = listaRecetas.recuperarReceta(i);
        if (receta) {
            QJsonObject recetaObject;
            recetaObject["nombre"] = receta->getNombre();
            recetaObject["categoria"] = receta->getCategoriaToInt();
            recetaObject["rutaImagen"] = receta->getRutaImagen();
            recetaObject["tiempoPreparacion"] = receta->getTiempoPreparacion();

            // Procesar autor
            Nombre autor = receta->getAutor();
            QJsonObject autorObject;
            autorObject["nombre"] = autor.getNombre();
            autorObject["apellido"] = autor.getApellido();
            recetaObject["autor"] = autorObject;

            // Preparación
            recetaObject["preparacion"] = receta->getPreparacion();

            // Ingredientes
            ListaIngredientes& ingredientes = receta->getListaIngredientes();
            QJsonArray ingredientesArray;

            int cantidadIngredientes = ingredientes.size();
            for (int j = 0; j < cantidadIngredientes; j++) {
                Ingrediente *ingrediente = ingredientes.recuperarIngrediente(j);
                if (ingrediente) {
                    QJsonObject ingredienteObject;

                    ingredienteObject["nombre"] = ingrediente->getNombre();
                    ingredienteObject["cantidad"] = ingrediente->getCantidad();
                    ingredienteObject["unidad"] = ingrediente->unidadMedidaToint();
                    ingredientesArray.append(ingredienteObject);
                }
            }
            recetaObject["ingredientes"] = ingredientesArray;

            recetasArray.append(recetaObject);
        }
    }

    QJsonDocument jsonDoc(recetasArray);
    file.write(jsonDoc.toJson());
    file.close();

    QMessageBox::information(this, "Guardado", "Las recetas han sido guardadas exitosamente.");
}

void MainWindow::cargarRecetas() {
    QString datosRecetas = QDir::currentPath() + "/recetas.json";
    QFile file(datosRecetas);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo para cargar las recetas\n"
                                            "asegurate que el archivo recetas.json\n se encuentre en la carpeta: " +QDir::currentPath());
        return;
    }

    QByteArray fileData = file.readAll();
    file.close();

    QJsonDocument jsonDoc(QJsonDocument::fromJson(fileData));
    QJsonArray recetasArray = jsonDoc.array();

    for (const QJsonValue &value : recetasArray) {
        QJsonObject recetaObject = value.toObject();

        Receta *receta = new Receta;
        receta->setNombre(recetaObject["nombre"].toString());
        receta->setCategoria(static_cast<Receta::Categoria>(recetaObject["categoria"].toInt()));
        receta->setRutaImagen(recetaObject["rutaImagen"].toString());
        receta->setTiempoPreparacion(recetaObject["tiempoPreparacion"].toInt());

        // Procesar autor
        QJsonObject autorObject = recetaObject["autor"].toObject();
        Nombre autor;
        autor.setNombre(autorObject["nombre"].toString());
        autor.setApellido(autorObject["apellido"].toString());
        receta->setAutor(autor);

        // Preparación
        receta->setPreparacion(recetaObject["preparacion"].toString());

        // Leer ingredientes
        QJsonArray ingredientesArray = recetaObject["ingredientes"].toArray();
        for (const QJsonValue &ingValue : ingredientesArray) {
            QJsonObject ingredienteObject = ingValue.toObject();
            Ingrediente *ingrediente = new Ingrediente;
            ingrediente->setNombre(ingredienteObject["nombre"].toString());
            ingrediente->setCantidad(ingredienteObject["cantidad"].toDouble());
            int unidadInt = ingredienteObject["unidad"].toInt();
            ingrediente->setUnidad(static_cast<Ingrediente::UnidadMedida>(unidadInt));
            receta->agregarIngrediente(ingrediente);
        }

        listaRecetas.agregarReceta(receta);
    }

    QMessageBox::information(this, "Cargado", "Las recetas han sido cargadas exitosamente.");
}


void MainWindow::closeEvent(QCloseEvent *event){
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmar", "¿Deseas guardar las recetas antes de salir?",
                                  QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);

    if (reply == QMessageBox::Yes) {
        guardarRecetas();
    } else if (reply == QMessageBox::Cancel) {
        event->ignore();
        return;
    }

    event->accept();
}

