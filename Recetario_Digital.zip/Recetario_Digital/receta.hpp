#ifndef RECETA_HPP
#define RECETA_HPP

#include <QString>
#include <QTextStream>
#include <iostream>
#include "nombre.hpp"
#include "listaIngredientes.hpp"

class Receta{
public:
    enum class Categoria {
        DESAYUNO,
        COMIDA,
        CENA,
        NAVIDEÑO
    };

private:
    int id;
    QString nombre;
    QString preparacion;
    QString rutaImagen;
    Categoria categoria;
    Nombre autor;
    int tiempoPreparacion;
    ListaIngredientes listaIngredientes;

public:
    Receta();
    Receta(const Receta&);
    ~Receta();

    void copiarTodo(const Receta&);

    void setNombre(const QString&);
    void setPreparacion(const QString&);
    void setCategoria(const Categoria&);
    void setAutor(const Nombre&);
    void setTiempoPreparacion(const int&);
    void setId(const int&);
    void setRutaImagen(const QString &newRutaImagen);

    void agregarIngrediente(Ingrediente *ingrediente);
    void eliminarTodosLosIngredientes();

    QString getNombre() const;
    QString getPreparacion() const;
    Categoria getCategoria() const;
    Nombre getAutor() const;
    int getTiempoPreparacion() const;
    int getId() const;
    ListaIngredientes& getListaIngredientes();
    QString getRutaImagen() const;

    Receta& operator=(const Receta&);

    bool operator==(const Receta& other) const;
    bool operator!=(const Receta& other) const;
    bool operator<(const Receta& other) const;
    bool operator>(const Receta& other) const;
    bool operator<=(const Receta& other) const;
    bool operator>=(const Receta& other) const;

    friend QTextStream& operator<<(QTextStream& , const Receta&);
    friend QTextStream& operator>>(QTextStream& , Receta& );

    QString getCategoriaToQstring() const;
    int getCategoriaToInt() const;

    static int compararPorNombre(const Receta&,const Receta&);
    static int compararPorTiempoPreparacion(const Receta&,const Receta&);


};

#endif // RECETA_HPP
