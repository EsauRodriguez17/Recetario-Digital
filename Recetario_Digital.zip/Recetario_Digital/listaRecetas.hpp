#ifndef LISTARECETAS_H
#define LISTARECETAS_H

#include "receta.hpp"
#include "exception.hpp"

class ListaRecetas{
private:
    Receta** recetas;
    int ultimaPosicion;
    int capacidad;

    void copiarTodo(const ListaRecetas& );
    void aumentarCapacidad();

public:
    ListaRecetas();
    ListaRecetas(const ListaRecetas& );
    ~ListaRecetas();

    ListaRecetas& operator=(const ListaRecetas& );

    void agregarReceta(Receta* );
    void eliminarReceta(int& );
    Receta* recuperarReceta(const int&) const;
    void anular();

    bool vacia() const;
    bool llena() const;
    bool posicionValida(const int& ) const;
    int size() const;

    int getPrimeraPosicion() const;
    int getUltimaPosicion() const;
    int getPosicionPrevia(const int&) const;
    int getSiguientePosicion(const int& ) const;
    int localiza(Receta*);

    int busquedaLineal(const Receta* , int (*cmp)(const Receta&, const Receta&)) const;
    int busquedaBinaria(const Receta* , int (*cmp)(const Receta&, const Receta&)) const;

    void quickSort(int (*cmp)(const Receta&, const Receta&));
    void quickSort(const int& ,const int&,int (*cmp)(const Receta&, const Receta&));

    void swap(const int&, const int&);
};

#endif // LISTARECETAS_H
