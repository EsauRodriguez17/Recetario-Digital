#include "listaIngredientes.hpp"

ListaIngredientes::ListaIngredientes() : ingredientes(nullptr), ultimaPosicion(-1), capacidad(15) {
    // Inicialización
    ingredientes = new Ingrediente*[capacidad];
}

ListaIngredientes::ListaIngredientes(const ListaIngredientes& otra){
    copiarTodo(otra);
}

ListaIngredientes::~ListaIngredientes(){
    anular();

    delete [] ingredientes;
}

void ListaIngredientes::copiarTodo(const ListaIngredientes & otra){

    this->ultimaPosicion=otra.ultimaPosicion;
    this->capacidad=otra.capacidad;

    this->ingredientes = new Ingrediente*[capacidad];

    for(int i=0;i<=ultimaPosicion;i++){
        this->ingredientes[i]=new Ingrediente(*otra.ingredientes[i]);
    }
}

ListaIngredientes& ListaIngredientes:: operator=(const ListaIngredientes& otra){
    copiarTodo(otra);

    return *this;
}

void ListaIngredientes::aumentarCapacidad(){
    capacidad *= 2;

    Ingrediente** nuevoArreglo = new Ingrediente*[capacidad];

    for (int i = 0; i <=ultimaPosicion; i++) {
        nuevoArreglo[i] = ingredientes[i];
    }

    delete[] ingredientes;
    ingredientes = nuevoArreglo;
}

bool ListaIngredientes::vacia(){
    return ultimaPosicion==-1;
}

bool ListaIngredientes::llena(){
    return ultimaPosicion == capacidad-1;
}

bool ListaIngredientes::posicionValida(const int& posicion){
    return posicion >= 0 && posicion <= ultimaPosicion;
}

int ListaIngredientes::size() const {
    return ultimaPosicion + 1;
}

void ListaIngredientes::insertarIngrediente(Ingrediente *ingrediente) {
    if (llena()) {
        aumentarCapacidad();
    }

    int posicion = buscarPosicionOrdenada(ingrediente);

    int i = ultimaPosicion;

    while (i >= posicion) {
        ingredientes[i + 1] = ingredientes[i];
        i--;
    }

    ingredientes[posicion] =ingrediente;
    ultimaPosicion++;
}

void ListaIngredientes::eliminarIngrediente(int & posicion){
    if (vacia()) {
        throw Exception("La lista está vacía, no hay ingredientes para eliminar.");
    }

    if (!posicionValida(posicion)) {
        throw Exception("Posicion invalida para eliminar el ingrediente.");
    }

    delete ingredientes[posicion];

    int i = posicion;
    while (i < ultimaPosicion) {
        ingredientes[i] = ingredientes[i + 1];
        i++;
    }

    ingredientes[ultimaPosicion] = nullptr;
    ultimaPosicion--;
}

int ListaIngredientes::getPrimeraPosicion(){
    if (vacia()) {
        return -1;
    }

    return 0;
}

int ListaIngredientes::getUltimaPosicion(){
    return ultimaPosicion;
}

int ListaIngredientes::getPosicionPrevia(const int & posicion){
    if (posicion == getPrimeraPosicion() || !posicionValida(posicion)) {
        return -1;
    }

    return posicion - 1;
}

int ListaIngredientes::getSiguientePosicion(const int & posicion){
    if (posicion == getUltimaPosicion() || !posicionValida(posicion)) {
        return -1;
    }

    return posicion + 1;
}

Ingrediente *ListaIngredientes::recuperarIngrediente(const int & posicion){
    if (!posicionValida(posicion)) {
        throw Exception("Posicion invalida para recuperar el elemento.");
    }

    return ingredientes[posicion];
}

int ListaIngredientes::busquedaLineal(const Ingrediente * objetivo, int (*cmp)(const Ingrediente &, const Ingrediente &)) const{

    for(int i=0;i<=ultimaPosicion;i++){
        if(cmp(*objetivo,*ingredientes[i])==0){
            return i;
        }
    }

    return -1;
}

int ListaIngredientes::busquedaBinaria(const Ingrediente * objetivo, int (*cmp)(const Ingrediente &, const Ingrediente &)) const{
    int izquierda=0;
    int derecha=ultimaPosicion;

    while(izquierda<=derecha){
        int mitad=(izquierda+derecha)/2;
        int resultado=cmp(*objetivo,*ingredientes[mitad]);

        if(resultado==0){
            return mitad;
        }
        else if(resultado<0){
            derecha=mitad-1;
        }
        else{
            derecha=mitad+1;
        }
    }

    return -1;
}

int ListaIngredientes::buscarPosicionOrdenada(const Ingrediente * ingrediente) const{
    int posicion=0;

    while(posicion<=ultimaPosicion && (ingrediente->getNombre() > ingredientes[posicion]->getNombre())){
        posicion++;
    }

    return posicion;
}

QString ListaIngredientes::toQstring() {
    QString resultado;

    resultado+="---INGREDIENTES---\n\n";
    for(int i=0;i<=ultimaPosicion;i++){
        resultado+=QString::number(i+1)+". "+ingredientes[i]->toQstring()+"\n";

        if (i < ultimaPosicion) {
            resultado += "─────────────────────────\n";
        }
    }

    return resultado;
}

void ListaIngredientes::anular(){

    for(int i=0;i<=ultimaPosicion;i++){
        delete ingredientes[i];
    }

    ultimaPosicion=-1;
}
