#include "listaRecetas.hpp"


ListaRecetas::ListaRecetas() : recetas(nullptr), ultimaPosicion(-1), capacidad(50) {
    recetas = new Receta*[capacidad];
}

ListaRecetas::ListaRecetas(const ListaRecetas& otra){
    copiarTodo(otra);
}

ListaRecetas::~ListaRecetas(){
    anular();
    delete [] recetas;
}

void ListaRecetas::copiarTodo(const ListaRecetas & otra){
    this->ultimaPosicion = otra.ultimaPosicion;
    this->capacidad = otra.capacidad;
    this->recetas = new Receta*[capacidad];

    for (int i = 0; i <= ultimaPosicion; i++) {
        this->recetas[i] = new Receta(*otra.recetas[i]);
    }
}

ListaRecetas& ListaRecetas::operator=(const ListaRecetas& otra){
    copiarTodo(otra);
    return *this;
}

void ListaRecetas::aumentarCapacidad(){
    capacidad *= 2;
    Receta** nuevoArreglo = new Receta*[capacidad];

    for (int i = 0; i <= ultimaPosicion; i++) {
        nuevoArreglo[i] = recetas[i];
    }

    delete[] recetas;
    recetas = nuevoArreglo;
}

bool ListaRecetas::vacia() const {
    return ultimaPosicion == -1;
}

bool ListaRecetas::llena() const {
    return ultimaPosicion == capacidad - 1;
}

int ListaRecetas::size() const {
    return ultimaPosicion + 1;
}

void ListaRecetas::agregarReceta(Receta *receta) {
    if (llena()) {
        aumentarCapacidad();
    }

    ultimaPosicion++;
    recetas[ultimaPosicion] = receta;
}

void ListaRecetas::eliminarReceta(int& posicion) {
    if (vacia()) {
        throw Exception("La lista está vacía, no hay recetas para eliminar.");
    }

    if (!posicionValida(posicion)) {
        throw Exception("Posicion invalida para eliminar la receta.");
    }

    delete recetas[posicion];

    for (int i = posicion; i < ultimaPosicion; i++) {
        recetas[i] = recetas[i + 1];
    }

    recetas[ultimaPosicion] = nullptr;
    ultimaPosicion--;
}

bool ListaRecetas::posicionValida(const int& posicion) const {
    return posicion >= 0 && posicion <= ultimaPosicion;
}

int ListaRecetas::getPrimeraPosicion() const {
    if (vacia()) {
        return -1;
    }
    return 0;
}

int ListaRecetas::getUltimaPosicion() const {
    return ultimaPosicion;
}

int ListaRecetas::getPosicionPrevia(const int& posicion) const {
    if (posicion == getPrimeraPosicion() || !posicionValida(posicion)) {
        return -1;
    }
    return posicion - 1;
}

int ListaRecetas::getSiguientePosicion(const int& posicion) const {
    if (posicion == getUltimaPosicion() || !posicionValida(posicion)) {
        return -1;
    }
    return posicion + 1;
}

int ListaRecetas::localiza(Receta * receta){
    for (int i = 0; i <= ultimaPosicion; ++i) {
        if (recetas[i] == receta) {
            return i;
        }
    }
    return -1;
}

Receta* ListaRecetas::recuperarReceta(const int& posicion) const {
    if (!posicionValida(posicion)) {
        throw Exception("Posicion invalida para recuperar la receta.");
    }
    return recetas[posicion];
}

int ListaRecetas::busquedaLineal(const Receta* objetivo, int (*cmp)(const Receta&, const Receta&)) const {
    for (int i = 0; i <= ultimaPosicion; i++) {
        if (cmp(*objetivo, *recetas[i]) == 0) {
            return i;
        }
    }
    return -1;
}

int ListaRecetas::busquedaBinaria(const Receta* objetivo, int (*cmp)(const Receta&, const Receta&)) const {
    if(vacia()){return -1;}

    int izquierda = 0;
    int derecha = ultimaPosicion;

    while (izquierda <= derecha) {
        int mitad = (izquierda + derecha) / 2;
        int resultado = cmp(*objetivo, *recetas[mitad]);

        if (resultado == 0) {
            return mitad;
        }
        else if (resultado < 0) {
            derecha = mitad - 1;
        }
        else {
            izquierda = mitad + 1;
        }
    }
    return -1;
}

void ListaRecetas::quickSort(int (*cmp)(const Receta &, const Receta &)){
    quickSort(0, ultimaPosicion, cmp);
}

void ListaRecetas::quickSort(const int& left, const int & right, int (*cmp)(const Receta &, const Receta &)){
    if (left >= right) {
        return;
    }

    int i = left;
    int j = right - 1;
    Receta pivot = *recetas[right];  // El pivote está en right

    while (i <= j) {
        while (i <= j && cmp(*recetas[i], pivot) <= 0) {
            i++;
        }
        while (i <= j && cmp(*recetas[j], pivot) >= 0) {
            j--;
        }
        if (i < j) {
            swap(i, j);
        }
    }

    swap(i,right);

    // Divide y vencerás
    quickSort(left, i - 1, cmp);
    quickSort(i + 1, right, cmp);
}

void ListaRecetas::swap(const int& i, const int& j){
    Receta *aux=recetas[i];
    recetas[i]=recetas[j];
    recetas[j] = aux;
}

void ListaRecetas::anular() {
    for (int i = 0; i <= ultimaPosicion; i++) {
        delete recetas[i];
    }
    ultimaPosicion = -1;
}
